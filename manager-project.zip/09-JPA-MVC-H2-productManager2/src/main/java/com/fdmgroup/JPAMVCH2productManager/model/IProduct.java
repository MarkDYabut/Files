package com.fdmgroup.JPAMVCH2productManager.model;

public interface IProduct {

}
