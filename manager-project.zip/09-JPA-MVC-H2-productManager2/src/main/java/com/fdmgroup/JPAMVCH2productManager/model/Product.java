package com.fdmgroup.JPAMVCH2productManager.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Component
@Scope(value="prototype", proxyMode=ScopedProxyMode.TARGET_CLASS)
@Entity
public class Product implements Serializable, IProduct{

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int productId;
	
	private String name;
	
	private String description;
	
	private String make;
	
	private int stock;
	
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.MERGE)
	@JoinColumn(name="SUPPLIER_ID", nullable = false)
	@JsonIgnore
	private Supplier supplier;
	
	private int price;
	
	public Product() {
		super();
	}
	public Product(String name, String description, String make, Supplier supplier, int price) {
		super();
		this.name = name;
		this.description = description;
		this.make = make;
		this.supplier = supplier;
		this.price = price;
	}
	
	public int getId() {
		return productId;
	}
	public void setId(int id) {
		this.productId = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getMake() {
		return make;
	}
	public void setMake(String make) {
		this.make = make;
	}
	public Supplier getSupplier() {
		return supplier;
	}
	public void setSupplier(Supplier supplier) {
		this.supplier = supplier;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", name=" + name + ", description=" + description + ", make=" + make
				+ ", stock=" + stock + ", supplier=" + supplier + ", price=" + price + "]";
	}
	public int getStock() {
		return stock;
	}
	public void setStock(int stock) {
		this.stock = stock;
	}
}
