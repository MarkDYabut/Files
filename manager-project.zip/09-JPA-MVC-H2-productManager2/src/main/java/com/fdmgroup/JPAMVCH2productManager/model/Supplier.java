package com.fdmgroup.JPAMVCH2productManager.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("prototype")
@Entity
public class Supplier implements Serializable, ISupplier {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)	
	private int supplierId;
	private String supplierName;
	private String supplierAddress;
	
	@OneToMany(mappedBy="supplier", fetch = FetchType.LAZY, cascade = CascadeType.MERGE)
	private List<Product> products = new ArrayList<Product>();
	
	public List<Product> getProducts() {
		return products;
	}
	public void setProducts(List<Product> products) {
		this.products = products;
	}
	public Supplier() {
		super();
	}
	public Supplier(String supplierName, String supplierAddress) {
		super();
		this.supplierName = supplierName;
		this.supplierAddress = supplierAddress;
	}
	public int getId() {
		return supplierId;
	}
	public void setId(int id) {
		this.supplierId = id;
	}
	public String getSupplierName() {
		return supplierName;
	}
	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}
	public String getSupplierAddress() {
		return supplierAddress;
	}
	public void setSupplierAddress(String supplierAddress) {
		this.supplierAddress = supplierAddress;
	}
	@Override
	public String toString() {
		return "Supplier [id=" + supplierId + ", supplierName=" + supplierName + ", supplierAddress=" + supplierAddress + "]";
	}
}
