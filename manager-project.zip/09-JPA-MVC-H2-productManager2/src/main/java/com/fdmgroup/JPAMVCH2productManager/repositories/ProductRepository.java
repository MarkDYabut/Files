package com.fdmgroup.JPAMVCH2productManager.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.fdmgroup.JPAMVCH2productManager.model.Product;

public interface ProductRepository extends JpaRepository<Product, Integer> {

	
	@Query("select m from Product m where upper(m.name) like concat('%', upper(:name), '%')")
	public List<Product> findByName(@Param("name") String name);
	
	@Query("select m from Product m where upper(m.description) like concat('%', upper(:description), '%')")
	public List<Product> findByDescription(@Param("description") String description);
	
	@Query("select m from Product m where upper(m.make) like concat('%', upper(:make), '%')")
	public List<Product> findByMake(@Param("make") String make);
	
	public List<Product> getByName(String name);
	
	@Modifying
	@Query("update Product p set p.name = ?1, p.description = ?2, p.price = ?3 where p.productId = ?4")
	public void updateProductById(String name, String description, int price, int productId);
	
}
