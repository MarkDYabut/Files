package com.fdmgroup.JPAMVCH2productManager.controllers;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.fdmgroup.JPAMVCH2productManager.exceptionHandlers.ProductNotFoundException;
import com.fdmgroup.JPAMVCH2productManager.model.Product;
import com.fdmgroup.JPAMVCH2productManager.model.Supplier;
import com.fdmgroup.JPAMVCH2productManager.repositories.ProductRepository;
import com.fdmgroup.JPAMVCH2productManager.repositories.SupplierRepository;

@Controller
public class MainController {
	
	private static final Logger LOGGER=LoggerFactory.getLogger(MainController.class);
	
	@Autowired
	private ProductRepository productRepo;
	@Autowired
	private SupplierRepository supplierRepo;
	@Autowired
	private ApplicationContext applicationContext;
	@Autowired 
	Product product;
	
	@RequestMapping({ "/", "/home" })
	public String goToHome() {
		return "index";
	}
	
	@RequestMapping("/addProduct")
	public String goToAddProduct(@RequestParam int id, Model model) {	
		Supplier supplier = supplierRepo.getOne(id);
		model.addAttribute("supplier", supplier);
		model.addAttribute("product", applicationContext.getBean(Product.class));
		return "addproduct";
	}
	
	@RequestMapping(value="/processAdd", method=RequestMethod.POST)
	public String goToConfirmation(@RequestParam int id, Product product, Model model) {
		Supplier supplier = supplierRepo.getOne(id);
		supplier.getProducts().add(product);
		product.setSupplier(supplier);
		productRepo.save(product);
		model.addAttribute("product",product);
		return "confirmation";
	}
	
	@RequestMapping("/showProducts")
	public String goToShowProducts(Model model) {
		List<Product> products = productRepo.findAll();
    	model.addAttribute("products",products);
		return "showproducts";
	}
	
	@RequestMapping("/searchProducts")
	public String goToSearchProduct(Model model) {
		model.addAttribute("product", product);
		return "searchproducts";
	}
	
	@RequestMapping("/processSearch")
	public String goToSearchResult(@RequestParam String searchterm, Model model) {
		List<Product> products = productRepo.findByName(searchterm);
		
		if (products.isEmpty()) {
			LOGGER.info("hello******* throwing ProductNotFoundException");
			throw new ProductNotFoundException();
		}
		
		model.addAttribute("products",products);
		return "showproducts";
	}
	
	@RequestMapping("/processSearchByDescription")
	public String goToSearchResultDescription(@RequestParam String searchterm, Model model) {
		
		try {
			List<Product> products = productRepo.findByDescription(searchterm);
			
			if (products.isEmpty()) {
				LOGGER.info("hello******* throwing ProductNotFoundException");
				throw new ProductNotFoundException();
			}
			
			model.addAttribute("products",products);
			return "showproducts";
		} catch (ProductNotFoundException e) {
	        throw new IllegalArgumentException("Product not found");
		}
		
	}
	
	@RequestMapping("/processSearchByMake")
	public String goToSearchResultMake(@RequestParam String searchterm, Model model) {
		List<Product> products = productRepo.findByMake(searchterm);
		model.addAttribute("products",products);
		return "showproducts";
	}
	
	@RequestMapping("/showSuppliers")
	public String goToShowSuppliers(Model model) {
		List<Supplier> suppliers = supplierRepo.findAll();
		model.addAttribute("suppliers", suppliers);
		return "showsuppliers";
	}
	
}