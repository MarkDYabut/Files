package com.fdmgroup.JPAMVCH2productManager.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fdmgroup.JPAMVCH2productManager.model.Product;
import com.fdmgroup.JPAMVCH2productManager.model.Supplier;
import com.fdmgroup.JPAMVCH2productManager.repositories.ProductRepository;
import com.fdmgroup.JPAMVCH2productManager.repositories.SupplierRepository;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:4200")
public class SecondaryRestController {
	
	@Autowired
	ProductRepository productRepo;
	
	@Autowired
	SupplierRepository supplierRepo;

	@GetMapping("products")
	public ResponseEntity<List<Product>> getRestProducts() {
		List<Product> products = productRepo.findAll();
		return new ResponseEntity <>(products, HttpStatus.OK);
	}
	
	@GetMapping("suppliers")
	public ResponseEntity<List<Supplier>> getRestSuppliers() {
		List<Supplier> suppliers = supplierRepo.findAll();
		return new ResponseEntity <>(suppliers, HttpStatus.OK);
	}
	
	@GetMapping("suppliers/{id}")
	public Optional<Supplier> getRestSupplier(@PathVariable String id) {
		Optional<Supplier> supplier = supplierRepo.findById(Integer.parseInt(id));
		return supplier;
	}
	
	@GetMapping("products/{id}")
	public Optional<Product> getRestProduct(@PathVariable String id) {
		Optional<Product> product = productRepo.findById(Integer.parseInt(id));
		return product;
	}
	
	@PostMapping(path="/addproduct", produces="application/json")
	public ResponseEntity<Product> postRestAddProduct(@RequestBody Product product) {
		Supplier supplier = supplierRepo.getOne(201);
		supplier.getProducts().add(product);
		product.setSupplier(supplier);
		return new ResponseEntity<> (product, HttpStatus.OK);
	}
	
	@DeleteMapping(path="/products/{id}")
	public void deleteRestProduct(@PathVariable String id) {
		productRepo.deleteById(Integer.parseInt(id));
	}
	
	@PutMapping(path="/suppliers/{id}", produces="application/json")
	public void updateRestSupplier(@PathVariable String id, @RequestBody Product[] products) {
		
		for (Product product : products) {
			System.out.println(product);
			System.out.println(product.getClass());

		}
		
	}
	
	@PutMapping(path="/products/{id}")
	public ResponseEntity<Product> updateRestProduct(@PathVariable String id, @RequestBody Product input) {

		Product product = productRepo.getOne(Integer.parseInt(id));
		product.setName(input.getName());
		product.setDescription(input.getDescription());
		product.setPrice(input.getPrice());
		productRepo.save(product);		
		
		return new ResponseEntity<>(input, HttpStatus.OK);
	}
	
	
	
	
}
